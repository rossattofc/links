/*******************************************************************************
**
** SCORM_API_wrapper.js (VERSÃO 2 - COM BUSCA AVANÇADA)
**
** Esta versão tenta encontrar a API de forma mais agressiva, procurando
** em janelas pais e na janela principal do navegador.
**
*******************************************************************************/

const scorm = (() => {
    let API = null;
    let isInitialized = false;

    // FUNÇÃO DE BUSCA MELHORADA
    function findAPI(win) {
        let findAPITries = 0;
        // Procura na janela atual e nas janelas "pai"
        while ((!win.API) && (win.parent) && (win.parent != win)) {
            findAPITries++;
            if (findAPITries > 500) {
                console.error("Erro: excedeu o número de tentativas para encontrar a API SCORM na hierarquia de pais.");
                return null;
            }
            win = win.parent;
        }

        // Se não encontrou, tenta procurar em janelas "opener" (caso o curso abra em um pop-up)
        if (win.API) {
            return win.API;
        } else if (window.opener) {
            return findAPI(window.opener);
        } else {
             return null;
        }
    }

    function init() {
        if (isInitialized) return;
        
        API = findAPI(window);

        if (API) {
            API.LMSInitialize("");
            isInitialized = true;
            console.log("SCORM API Inicializada com sucesso.");
            setValue("cmi.core.lesson_status", "incomplete");
            commit();
        } else {
            console.error("A API SCORM não foi encontrada. Verifique se o curso está sendo executado a partir de um LMS e se a estrutura do pacote .ZIP está correta (sem pastas internas).");
        }
    }

    function setValue(param, value) {
        if (isInitialized && API) {
            return API.LMSSetValue(param, value);
        }
        return false;
    }

    function commit() {
        if (isInitialized && API) {
            return API.LMSCommit("");
        }
        return false;
    }

    function exit() {
        if (isInitialized && API) {
            API.LMSFinish("");
            isInitialized = false;
            API = null;
            console.log("Conexão SCORM finalizada.");
        }
    }

    // Função para registrar a conclusão e a nota (VERSÃO MELHORADA)
    function complete(score) {
        if (!isInitialized) return;
        
        let lessonStatus = "completed"; // Status padrão
        
        if (score !== undefined) {
            const passingScore = 70; // Defina uma nota de aprovação, ex: 70
            setValue("cmi.core.score.min", "0");
            setValue("cmi.core.score.max", "100");
            setValue("cmi.core.score.raw", score.toString());
            
            if (score >= passingScore) {
                lessonStatus = "passed";
            } else {
                lessonStatus = "failed";
            }
        }

        setValue("cmi.core.lesson_status", lessonStatus);
        setValue("cmi.core.exit", "suspend");

        const success = commit();
        if (success) {
            console.log(`Status enviado ao AVA: ${lessonStatus}. Pontuação: ${score}. Dados salvos.`);
        } else {
            console.error("Falha ao salvar dados no AVA.");
        }
    }
    
    return {
        init,
        exit,
        complete
    };
})();